const Post = require('../models/Post');
const User = require('../models/User');

exports.createPost = async (req, res) => {
  try {
    const { userId, content } = req.body;

    if (content.length > 280) {
      return res.status(400).json({ message: 'Post content exceeds 280 characters' });
    }

    const post = await Post.create({ content, UserId: userId });

    res.status(201).json(post);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deletePost = async (req, res) => {
  try {
    const { postId } = req.params;
    await Post.destroy({ where: { id: postId } });

    res.status(200).json({ message: 'Post deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.viewPosts = async (req, res) => {
  try {
    const posts = await Post.findAll({ include: User, order: [['createdAt', 'DESC']] });

    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.viewUserPosts = async (req, res) => {
  try {
    const { userId } = req.params;
    const posts = await Post.findAll({ where: { UserId: userId }, order: [['createdAt', 'DESC']] });

    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
