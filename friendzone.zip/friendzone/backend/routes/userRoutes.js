const express = require('express');
const { register, login, editProfile, viewProfile } = require('../controllers/userController');

const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.put('/profile', editProfile);
router.get('/profile/:userId', viewProfile);

module.exports = router;
