const express = require('express');
const { createPost, deletePost, viewPosts, viewUserPosts } = require('../controllers/postController');

const router = express.Router();

router.post('/', createPost);
router.delete('/:postId', deletePost);
router.get('/', viewPosts);
router.get('/user/:userId', viewUserPosts);

module.exports = router;
