import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

function Profile() {
  const { userId } = useParams();
  const [profile, setProfile] = useState({});
  const [bio, setBio] = useState('');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    const fetchProfile = async () => {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/users/profile/${userId}`);
      setProfile(response.data);
    };
    fetchProfile();
  }, [userId]);

  const handleEditProfile = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.put(`${process.env.REACT_APP_API_URL}/users/profile`, { userId, bio, phone }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Profile updated successfully');
    } catch (error) {
      alert('Profile update failed: ' + error.response.data.message);
    }
  };

  return (
    <div className="container">
      <h2>Profile</h2>
      <form onSubmit={handleEditProfile}>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input type="email" className="form-control" value={profile.email} disabled />
        </div>
        <div className="mb-3">
          <label className="form-label">Bio</label>
          <input
            type="text"
            className="form-control"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Phone</label>
          <input
            type="text"
            className="form-control"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary">Edit Profile</button>
      </form>
    </div>
  );
}

export default Profile;
