import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Home() {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchPosts = async () => {
      const response = await axios.get(`${process.env.REACT_APP_API_URL}/posts`);
      setPosts(response.data);
    };
    fetchPosts();
  }, []);

  return (
    <div className="container">
      <h2>All Posts</h2>
      {posts.map((post) => (
        <div key={post.id} className="card mb-3">
          <div className="card-body">
            <h5 className="card-title">{post.User.email}</h5>
            <p className="card-text">{post.content}</p>
            <p className="card-text"><small className="text-muted">Posted on {new Date(post.timestamp).toLocaleString()}</small></p>
          </div>
        </div>
      ))}
    </div>
  );
}

export default Home;
